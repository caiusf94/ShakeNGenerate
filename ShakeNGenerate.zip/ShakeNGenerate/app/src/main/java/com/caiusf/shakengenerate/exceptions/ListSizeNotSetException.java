package com.caiusf.shakengenerate.exceptions;

/**
 * Created by caius.florea on 17-Jan-17.
 */

public class ListSizeNotSetException extends Exception {
    public ListSizeNotSetException(){
        super();
    }
}
