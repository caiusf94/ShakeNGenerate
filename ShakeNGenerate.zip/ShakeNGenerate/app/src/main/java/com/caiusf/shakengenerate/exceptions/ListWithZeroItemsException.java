package com.caiusf.shakengenerate.exceptions;

/**
 * Created by caius.florea on 04-Jan-17.
 */

public class ListWithZeroItemsException extends Exception{
    public ListWithZeroItemsException(){
        super();
    }
}
