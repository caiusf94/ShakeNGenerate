package com.caiusf.shakengenerate.exceptions;

/**
 * Created by caius.florea on 18-Jan-17.
 */

public class ListSizeTooLargeException extends Exception {
    public ListSizeTooLargeException(){
        super();
    }
}
